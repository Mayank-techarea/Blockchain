import hashlib
import time

class Block:
    def __init__(self, index, data, previous_hash):
        self.index = index
        self.timestamp = time.time()
        self.data = data
        self.previous_hash = previous_hash
        self.nonce = 0
        self.hash = self.calculate_hash()

    def calculate_hash(self):
        content = f"{self.index}{self.timestamp}{self.data}{self.previous_hash}{self.nonce}"
        return hashlib.sha256(content.encode()).hexdigest()

# Create blocks
genesis_block = Block(0, "Genesis Block", "0")
block1 = Block(1, "Block 1 Data", genesis_block.hash)
block2 = Block(2, "Block 2 Data", block1.hash)

# Display blocks
for block in [genesis_block, block1, block2]:
    print(f"Block {block.index} Hash: {block.hash}")

# Modify block1
block1.data = "Tampered Data"
block1.hash = block1.calculate_hash()

print("\nAfter Tampering Block 1:")
print(f"Block 1 Hash: {block1.hash}")
print(f"Block 2 Previous Hash:{block2.previous_hash}")