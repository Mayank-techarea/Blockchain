import random

# Proof of Work
pow_miner = {'name': 'Alice', 'power': random.randint(10, 100)}
print(f"PoW Selected: {pow_miner['name']} with power {pow_miner['power']}")

# Proof of Stake
pos_stakers = [{'name': 'Bob', 'stake': random.randint(100, 1000)},
               {'name': 'Charlie', 'stake': random.randint(100, 1000)}]
selected_pos = max(pos_stakers, key=lambda x: x['stake'])
print(f"PoS Selected: {selected_pos['name']} with stake {selected_pos['stake']}")

# Delegated Proof of Stake
delegates = ['Dave', 'Eve', 'Frank']
votes = {'Dave': 2, 'Eve': 5, 'Frank': 3}
selected_dpos = max(votes, key=votes.get)
print(f"DPoS Selected Delegate: {selected_dpos} with {votes[selected_dpos]} votes")